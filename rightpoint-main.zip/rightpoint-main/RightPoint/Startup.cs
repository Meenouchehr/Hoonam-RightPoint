﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(RightPoint.Startup))]
namespace RightPoint
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
